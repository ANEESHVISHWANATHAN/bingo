import ProductDetail from '../../pages/ProductDetail';

export default function ProductDetailExample() {
  return <ProductDetail />;
}
