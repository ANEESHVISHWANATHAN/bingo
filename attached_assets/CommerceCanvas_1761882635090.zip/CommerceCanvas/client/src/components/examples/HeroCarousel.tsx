import HeroCarousel from '../HeroCarousel';

export default function HeroCarouselExample() {
  return <HeroCarousel />;
}
